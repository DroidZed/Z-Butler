BLUE = '\033[94m'
CYAN = '\033[96m'
GREEN = '\033[92m'
NOCOLOR = '\033[0m'
BOLD = '\033[1m'
ITALIC = '\x1B[3m'
NORMAL = '\x1B[0m'
RED = "\u001b[31m"