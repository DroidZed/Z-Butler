
from datetime import datetime


def days_between(d1, d2):
    d1 = datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.strptime(d2, "%Y-%m-%d")
    return abs((d2 - d1))


def main() -> None:
    print(days_between("2022-10-6", "2021-09-07").days / 356)


if __name__ == '__main__':
    main()
